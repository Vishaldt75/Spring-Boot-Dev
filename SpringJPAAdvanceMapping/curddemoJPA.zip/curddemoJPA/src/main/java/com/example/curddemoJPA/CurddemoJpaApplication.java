package com.example.curddemoJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurddemoJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurddemoJpaApplication.class, args);
	}

}
